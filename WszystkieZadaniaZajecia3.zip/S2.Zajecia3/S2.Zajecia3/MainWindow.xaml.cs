﻿using System.Collections;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Motoryzacja;

namespace S2.Zajecia3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        void WyswietlPojazd(IEnumerable<Pojazd> pojazdy)
        {
            lsb_listaPojazdow.Items.Clear();
            foreach(Pojazd pojazd in pojazdy)
            {
                lsb_listaPojazdow.Items.Add(pojazd.ToString());
                
            }
        }

        private void btn_WyswietlPojazd_Click(object sender, RoutedEventArgs e)
        {
            Pojazd[] tablicaPojazdow = new Pojazd[4];
            tablicaPojazdow[0] = new Pojazd("Fiat", 4, 150);
            tablicaPojazdow[0].Nazwa = "Maluch";
            tablicaPojazdow[1] = new PojazdMechaniczny("Mercedes", 4,250,150);
            tablicaPojazdow[2] = new Pojazd() { Nazwa = "VW", LiczbaKol = 4, Predkosc = 200};
            tablicaPojazdow[3] = new Samochod("Civic", 4, 175, 5, "Honda");
            WyswietlPojazd(tablicaPojazdow);
            tablicaPojazdow[0].WyswietlHistorie(lsb_listaPojazdow);
        }
    }
}