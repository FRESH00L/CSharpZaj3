﻿using System.Numerics;
using System.Windows.Controls;

namespace Motoryzacja
{
    public struct RejestrNazw
    {
        public DateTime Date { get; set; }
        public String Nazwa { get; set; }
        public RejestrNazw(DateTime _data, String _nazwa) 
        {
            Nazwa = _nazwa;
            Date = _data.Date;
        }
        public override string ToString()
        {
            return $"Data modyfikacji: {Date} nazwa: {Nazwa}";
        }
    }

    public class Pojazd
    {
        private String nazwa;
        private int liczbaKol;
        private double predkosc;
        private static int liczbaPorzadkowa;
        private int lp;
        private List<RejestrNazw> historiaNazw = new List<RejestrNazw>();
       
        public int Lp
        {
            get { return liczbaPorzadkowa; }
        }
        public String Nazwa
        {
            get { if (historiaNazw.Count > 0) { String nazwy = ""; foreach (RejestrNazw rn in historiaNazw) { nazwy += rn.Nazwa; } return nazwy; } else return "Brak historii nazw"; }
            set { if (nazwa != value) { nazwa = value; historiaNazw.Add(new RejestrNazw(DateTime.Now, value)); } }
        }
        public int LiczbaKol
        {
            get { return liczbaKol; }
            set
            {
                if (value <=0) { throw new ArgumentException("Nieprawidłowa liczba kół"); }
                liczbaKol = value;
            }
        }
        public double Predkosc
        {
            get { return predkosc; }
            set
            {
                if (value < 0) { throw new ArgumentException("Nieprawidłowa wartość prędkości"); }
                predkosc = value;
            }
        }
        static Pojazd()
        {
            liczbaPorzadkowa = 0;
        }
        public Pojazd(String _nazwa, int _liczbaKol, double _predkosc)  :this()
        {
            Nazwa = _nazwa; 
            LiczbaKol= _liczbaKol;
            Predkosc = _predkosc;
        }
        public Pojazd(String _nazwa,double _predkosc) 
            :this(_nazwa,4,_predkosc)
        {
        }
        public Pojazd()
        {
            lp = ++liczbaPorzadkowa;
        }
        public void WyswietlHistorie (ListBox listbox)
        {
            listbox.Items.Clear ();
            foreach(var rejestr in historiaNazw)
                listbox.Items.Add(rejestr.ToString());
        }
        public virtual String ToString()
        {
            return $"Pojazd: {Nazwa} \no liczbie kół: {LiczbaKol} \ni max prędkości: {Predkosc} {lp}/{liczbaPorzadkowa}";
        }
    }
    public class PojazdMechaniczny : Pojazd
    {
        private int mocSilnika;
        public int MocSilnika
        {
            get { return mocSilnika; }
            set
            {
                if (value <+ 0) { throw new ArgumentException("Błędna moc silnika"); }
            }
        }
        public PojazdMechaniczny(String _nazwa, int _liczbaKol, double _predkosc, int _mocSilnika)   :base(_nazwa,_liczbaKol,_predkosc)
        {
            MocSilnika = mocSilnika;
        }
        public override String ToString()
        {
            return $"{base.ToString()} \nMoc silnika: {mocSilnika}";
        }
    }
    public class Samochod : Pojazd
    {
        private int liczbaPasazerow;
        private String marka;
        public int LiczbaPasazerow
        {
            get { return liczbaPasazerow; }
            set { if (value <= 0) { throw new ArgumentException("Nieprawidłowa liczba pasażerów"); } }

        }
        public String Marka
        {
            get { return marka; }
            set { marka = value; }
        }
        public Samochod(String _nazwa, int _liczbaKol, double _predkosc, int _liczbaPasazerow, String _marka) : base(_nazwa, _liczbaKol, _predkosc)
        {
            liczbaPasazerow = _liczbaPasazerow;
            marka = _marka;
        }
        public override String ToString()
        {
            return $"{base.ToString()} \nliczba pasażerów: {liczbaPasazerow} \nmarka: {marka}";
        }

    }
}
