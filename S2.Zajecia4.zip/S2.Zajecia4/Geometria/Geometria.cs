﻿namespace Geometria
{
    public abstract class Bryla
    {
        private String nazwa;
        private double gestosc;
        private double cenaZaKg;

        public String Nazwa
        {
            get { return nazwa; }
        }
        public double Gestosc
        {
            get { return gestosc; }
        }
        public double CenaZaKg
        {
            get { return cenaZaKg; }
        }
        public Bryla(string nazwa, double gestosc, double cenaZaKg)
        {
            this.nazwa = nazwa;
            this.gestosc = gestosc;
            this.cenaZaKg = cenaZaKg;
        }

        public abstract double ObliczObjetosc();
        
        public double ObliczMase()
        {
            return this.gestosc * ObliczObjetosc();
        }
        public double ObliczCene()
        {
            return this.cenaZaKg * ObliczMase();
        }
        public override string ToString()
        {
            return $"Bryła: {Nazwa}, Gęstość: {gestosc}, Cena za kilo: {cenaZaKg}";
        }
    }
    public class Kula : Bryla
    {
        private double promien;
        public double Promien
        {
            get { return promien; }
        }
        public Kula(String _nazwa, double _gestosc, double _cena, double _promien) :base(_nazwa,_gestosc,_cena)
        {
            promien = _promien;
        }
        public override double ObliczObjetosc()
        {
            return (4.0/3.0) * Math.PI * Math.Pow(Promien, 3);
        }
       
    }
    public class Stozek : Bryla
    {
        private double wysokosc;
        private double promien;
        public double Wysokosc
        {
            get { return wysokosc; }
        }
        public double Promien
        {
            get { return promien; }
        }
        
        public Stozek(String _nazwa, double _gestosc, double _cena,double _wysokosc, double _promien):base(_nazwa, _gestosc, _cena)
        {
            wysokosc = _wysokosc;
            promien = _promien;
        }
        public override double ObliczObjetosc()
        {
            return (1.0 / 3.0) * wysokosc * Math.PI * Math.Pow(promien, 2);
        }
    }
}