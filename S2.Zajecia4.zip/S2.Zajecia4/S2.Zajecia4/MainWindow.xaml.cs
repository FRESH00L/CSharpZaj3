﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Geometria;

namespace S2.Zajecia4
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

      

        private void btn_ObliczStozek_Click(object sender, RoutedEventArgs e)
        {
            Stozek stozek = new Stozek("Stożek", 1, 5.0, 20, 2);
            double obj = stozek.ObliczObjetosc();
            double masa = stozek.ObliczMase();
            double cena = stozek.ObliczCene();
            String info = $"\nObjętość:{obj}, Masa:{masa}, Cena:{cena}";
            lbl_Wynik.Content = stozek.ToString() + info;
            
        }

        private void btn_ObliczKule_Click(object sender, RoutedEventArgs e)
        {
            Kula kula = new Kula("Kula", 100, 24.0, 23.0);
            double obj = kula.ObliczObjetosc();
            double masa = kula.ObliczMase();
            double cena = kula.ObliczCene();
            String info = $"\nObjętość:{obj}, Masa:{masa}, Cena:{cena}";
            lbl_Wynik.Content = kula.ToString() + info;
        }

        private void btn_Oblicz1_Click(object sender, RoutedEventArgs e)
        {
            var oknoWejsciowe = new DaneWejscioweOkno();

            oknoWejsciowe.ShowDialog();
            double h, w, P;

            h = oknoWejsciowe.Wysokosc;
            w = oknoWejsciowe.Szerokosc;
            P = w * h;

            var oknoWyjsciowe = new DaneWyjscioweOkno(P);
            //oknoWyjsciowe.tbk_Pole.Text = $"Pole wynosi: {P}";
            oknoWyjsciowe.ShowDialog();

        }
    }
}
